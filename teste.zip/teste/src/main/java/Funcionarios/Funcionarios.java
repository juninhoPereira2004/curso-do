package Funcionarios;

public class Funcionarios {
    private String nome;
    private String funcao;
    private String setor;

    public Funcionarios(String nome, String funcao, String setor) {
        this.nome = nome;
        this.funcao = funcao;
        this.setor = setor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public String getSetor() {
        return setor;
    }

    public void setSetor(String setor) {
        this.setor = setor;
    }

    public void imprimirInformacoes() {
        System.out.println("Nome: " + nome);
        System.out.println("Funcao: " + funcao);
        System.out.println("Setor: " + setor);
    }
}
