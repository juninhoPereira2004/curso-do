package org.Animais;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Animal[] animais = new Animal[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("Cadastro do Animal #" + (i + 1));
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Espécie: ");
            String especie = scanner.nextLine();
            System.out.print("Alimentação: ");
            String alimentacao = scanner.nextLine();

            Animal animal = new Animal(nome, especie, alimentacao);

            animais[i] = animal;
        }

        System.out.println("\nLista de Animais Cadastrados:");
        for (Animal animal : animais) {
            System.out.println("Nome: " + animal.getNome());
            System.out.println("Espécie: " + animal.getEspecie());
            System.out.println("Alimentação: " + animal.getAlimentacao());
            System.out.println();
        }
    }
}

