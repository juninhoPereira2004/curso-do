package Funcionarios;

import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Funcionarios[] funcionariosArray = new Funcionarios[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("Cadastro do Funcionário #" + (i + 1));
            System.out.print("Nome: ");
            String nome = scanner.nextLine();
            System.out.print("Função: ");
            String funcao = scanner.nextLine();
            System.out.print("Setor : ");
            String setor = scanner.nextLine();

            Funcionarios funcionario = new Funcionarios(nome, funcao, setor);

            funcionariosArray[i] = funcionario;
        }

        System.out.println("\nLista de Funcionários Cadastrados:");
        for (Funcionarios funcionario : funcionariosArray) {
            System.out.println("Nome: " + funcionario.getNome());
            System.out.println("Função: " + funcionario.getFuncao());
            System.out.println("Setor: " + funcionario.getSetor());
            System.out.println();
        }
    }
}
